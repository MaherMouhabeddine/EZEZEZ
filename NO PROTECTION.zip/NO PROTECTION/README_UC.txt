﻿[Xenon Internal] ROB RUN - Internal DX11 Cheat (ESP/Aimbot/Trigger/Misc)

Status: Undetected status unknown (use at your own risk). Built for ROB RUN (Unity/IL2CPP), offsets based on 2026-11-17 dump.
Type: Internal DLL (DX11 Present hook, ImGui overlay/menu)
Menu key: INSERT (default)

[ Features ]

Visuals / ESP
- Player ESP: Box, Skeleton, Name, Weapon, Distance, Armor, Health, Team marker
- Filters/toggles: Show self, Show clan, Show police, Max distance, Skeleton/line width
- Player chams: Enable, tint, material chams, visibility check, multiple styles (Flat/Ice/Plasma/Ember/Obsidian/Abyss/Pulse/Invisible/Marble), opacity
- Local visuals: Local box/skeleton/name/weapon/distance/armor/chams (style, tint, opacity), colors
- Tracers: Shot tracers with fade, width, glow
- OOF indicators: Enable, radius, size, style
- Crosshair maker: Enable, styles (Cross, Circle, Dot, T-Shape, X, Triangle, Star, Star of David, Smiley, Diamond), size/thickness/gap/opacity, center dot, outline, spin + speed, colors

World
- World markers: Loot, Loot nodes, Containers, Doors, Dropped loot, Vehicle loot, Vehicle markers, Occupants
- Loot rarity filters: No rarity/Common/Uncommon/Rare/Epic/Legendary/Exotic
- Stretch Resolution (post-process): Enable + horizontal % slider (50-100%) for centered horizontal stretch/crop effect

Aimbot (mouse aim)
- Enable, activation/bind mode, aim key
- Bone selection + "Nearest bone to crosshair"
- FOV: radius, 360 FOV option, draw circle/fill/gradient, opacity/spin options, camera FOV override
- Smoothing, calibration, distance limit
- Sticky target, closest-first
- Visibility/LOS check
- Target filters: ignore party (team check), ignore downed, target clan, target police
- No recoil: enable + pull-down strength (mouse compensation)

Triggerbot / Auto
- Triggerbot: enable, activation mode/key, delay
- Auto pistol: enable, fire interval (hold shoot with pistol to spam)

Misc / Config
- Skin changer: enable + preset selection (best-effort/config-based; live replacement is game/build dependent)
- Config system: Save/Load to %LOCALAPPDATA%\XenonInternal\config.bin (persists ESP/aim/trigger/visuals/world/colors/skin settings)
- HUD/Menu: watermark, custom cursor, VSync toggle, exclude capture, menu keybind, GUI renders on top of ESP
- Logs: %LOCALAPPDATA%\XenonInternal\xenon.log

[ Requirements / How to Launch ]

Package contents (ReadyBuild folder)
- XenonInternal.dll        (cheat)
- ioctl-injector.exe       (loader/injector)
- orelia-mapper.exe        (mapper)
- orelia-ioctl.sys         (vulnerable driver)
- Inject.bat               (run script)

Requirements
- Windows 10/11 x64
- ROB RUN installed and running (target process: ROB RUN.exe)
- Administrator privileges (mapper/driver loading and injection require elevation)
- Antivirus/Windows Defender: the injector/driver may be flagged (e.g. HackTool). Add exclusions for the folder if needed.
- For vulnerable-driver mappers of this type, Windows security features often must be disabled for the driver to load/work:
  - Disable Core Isolation / Memory Integrity (HVCI)
  - Disable Virtualization-based Security (VBS) where applicable
  - In some setups: disable Secure Boot and/or disable Hyper-V/hypervisor (e.g. `bcdedit /set hypervisorlaunchtype off` then reboot)
  - Exact requirements depend on your Windows build/configuration; if mapping fails, check these settings and `inject.log`
- Use at your own risk. This is for a protected online game environment; detection/bans are possible.

How to use
1. Extract/copy the ReadyBuild folder somewhere on disk.
2. (If needed) add a Defender/AV exclusion for the folder.
3. Launch ROB RUN and wait until you are in-game/load as needed.
4. Right-click Inject.bat -> Run as administrator.
5. Wait for completion and check `inject.log` (and `%LOCALAPPDATA%\XenonInternal\xenon.log`) for status.
6. Press INSERT to open/close the menu.

[ Notes ]
- Offsets are dump-specific (current build references 2026-11-17 offsets). After game updates, offsets/features may break until updated.
- "Ignore downed" and targeting/ESP logic use best-effort game state; behavior may vary by game build/state.
- Stretch Resolution is a post-process overlay effect (center crop + horizontal stretch), not a true engine render-resolution change.
- Configs from older schema versions are incompatible; save a new config if load fails.
- No guarantees of stability, safety, or undetection.
