@echo off
cd /d "%~dp0"
echo ===== XenonInternal inject %DATE% %TIME% ===== > inject.log
echo --- mapper (load vulnerable driver) --- >> inject.log
orelia-mapper.exe orelia-ioctl.sys <nul >> inject.log 2>&1
echo MAPPER_EXIT=%ERRORLEVEL% >> inject.log
echo --- injector (inject XenonInternal.dll into ROB RUN.exe) --- >> inject.log
ioctl-injector.exe "%~dp0XenonInternal.dll" <nul >> inject.log 2>&1
echo INJECTOR_EXIT=%ERRORLEVEL% >> inject.log
echo --- done --- >> inject.log
echo Done. See inject.log for details.
pause
